<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>About Page</title>
</head>
  <body>
    <h1> This is About Page from Controller</h1>
    <a href="{{route('contact.page')}}">Contact</a>
</body>  

</html>
